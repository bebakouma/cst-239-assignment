# CST-239 Assignment

## Screencast Video
Watch my full screencast demonstration here:

## Click to watch on Loom : https://www.loom.com/share/e9a1f84eda3840a59b10f9c6df61f69d


## How to Compile and Run

```
javac -d out $(Get-ChildItem -Recurse src -Filter *.java).FullName
java -cp out edu.gcu.storefront.StoreFrontApp
```


## Optional GitHub Repository
You can also browse the source and documentation in my public GitHub repository:
 https://github.com/bebakouma/cst-239-assignment/tree/master
